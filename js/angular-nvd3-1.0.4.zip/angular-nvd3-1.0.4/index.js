require('dist/angular-nvd3.js');
module.exports = 'nvd3';